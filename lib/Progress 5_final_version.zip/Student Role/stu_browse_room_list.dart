import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:mobile_app_project/Student%20Role/stu_booking_list.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:mobile_app_project/config.dart'; // Import the config file

// Enum for room status
enum RoomStatus { free, reserved, pending, disabled }

class StuBrowseRoomList extends StatefulWidget {
  final String role;
  final String accessToken;
  final TextEditingController _searchController = TextEditingController();

  // Constructor to receive the role and access token
  StuBrowseRoomList({Key? key, required this.role, required this.accessToken})
      : super(key: key);

  @override
  _StuBrowseRoomListState createState() => _StuBrowseRoomListState();
}

class _StuBrowseRoomListState extends State<StuBrowseRoomList> {
  List<Map<String, dynamic>> rooms = [];
  List<Map<String, dynamic>> filteredRooms =
      []; // To store the filtered rooms based on search query
  final TextEditingController _searchController = TextEditingController();
  late Timer _timer; // Timer for polling

  @override
  void initState() {
    super.initState();
    _fetchRooms(); // Fetch room data when the widget is initialized
    _startPolling(); // Start polling

    // Add listener to the search field to filter rooms as the user types
    _searchController.addListener(() {
      _filterRooms(_searchController.text);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _timer.cancel(); // Cancel the timer when widget is disposed
    super.dispose();
  }

  void _startPolling() {
    // Poll every 30 seconds
    _timer = Timer.periodic(const Duration(seconds: 15), (timer) {
      _fetchRooms();
    });
  }

  // Function to filter rooms based on search query
  void _filterRooms(String query) {
    final filtered = rooms.where((room) {
      final roomName = room['name'].toLowerCase();
      return roomName.contains(query.toLowerCase());
    }).toList();

    setState(() {
      filteredRooms = filtered;
    });
  }

  Future<void> _fetchRooms() async {
    final response = await http.get(
      Uri.parse('${Config.baseUrl}/rooms'),
      headers: {
        'Authorization': 'Bearer ${widget.accessToken}',
      },
    );

    if (response.statusCode == 200) {
      try {
        var responseData = json.decode(response.body);

        if (responseData['rooms'] is List) {
          List<Map<String, dynamic>> fetchedRooms = [];
          for (var room in responseData['rooms']) {
            List<Map<String, dynamic>> slots =
                (room['slots'] as List).map((slot) {
              return {
                'time': slot['time'],
                'status': RoomStatus.values.firstWhere(
                  (e) => e.toString().split('.').last == slot['status'],
                  orElse: () => RoomStatus.free,
                ),
              };
            }).toList();

            fetchedRooms.add({
              'name': room['roomName'] ?? 'Unnamed',
              'roomID': room['roomID'],
              'capacity': room['capacity']?.toString() ?? 'N/A',
              'wifi': room['wifi'] == 0 ? 'No' : 'Free',
              'imagePath': room['imagePath'] ?? '',
              'slots': slots,
            });
          }

          setState(() {
            rooms = fetchedRooms;
            filteredRooms = fetchedRooms; // Initially show all rooms
          });

          // Success toast
          MotionToast.success(
            title: Text("Success"),
            description: Text("Rooms data loaded successfully."),
          ).show(context);
        } else {
          print(
              "Response data is not a list, it's a map. Response: $responseData");
        }
      } catch (e) {
        print("Error decoding response body: $e");

        // Error toast for decoding issues
        MotionToast.error(
          title: Text("Error"),
          description: Text("Failed to decode room data."),
        ).show(context);
      }
    }
// else {
    //     // print('Failed to load room data. Status code: ${response.statusCode}');

    //     // Error toast for failed request
    //     MotionToast.error(
    //       title: Text("Error"),
    //       description: Text(
    //           "Failed to load room data. Status code: ${response.statusCode}"),
    //     ).show(context);
    //   }
  }

  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    String dayOfMonth = DateFormat('d').format(now);
    String dayOfWeek = DateFormat.EEEE().format(now);
    String monthYear = DateFormat('MMMM yyyy').format(now);

    bool hasAvailableRooms = filteredRooms.any((room) =>
        room['slots'].any((slot) => slot['status'] == RoomStatus.free));

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Search TextField
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterRooms(
                              ''); // Clear the filtered rooms when the text is cleared
                        },
                      )
                    : null, // If the text is empty, no icons are displayed
                hintText: 'Browse room name',
                filled: true,
                fillColor: Color(0xFFECE6F0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged:
                  _filterRooms, // Call the filter function on every change
            ),

            SizedBox(height: 20), // Adding some space after the search field

            // Status labels
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatusLabel('Free', Color(0xFF4DC591)),
                _buildStatusLabel('Reserved', Color(0xFFFF0000)),
                _buildStatusLabel('Pending', Color(0xFFFFB948)),
                _buildStatusLabel('Disabled', Color(0xFF88889D)),
              ],
            ),
            SizedBox(height: 20),
            Expanded(
              child: filteredRooms.isEmpty
                  ? Center(
                      child: Text(
                        "No rooms found for your search.",
                        style: TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    )
                  : (hasAvailableRooms
                      ? ListView.builder(
                          itemCount: filteredRooms.length,
                          itemBuilder: (context, index) {
                            final room = filteredRooms[index];
                            return _buildRoomCard(
                              room['name'] ?? 'Unnamed',
                              room['roomID'],
                              room['capacity'] ?? 'N/A',
                              room['wifi'] ?? 'N/A',
                              room['imagePath'] ?? '',
                              room['slots'],
                              // Pass the slots data
                            );
                          },
                        )
                      : Center(
                          child: Text(
                            "Currently, no free rooms are available.",
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )),
            ),
          ],
        ),
      ),
    );
  }

  // Helper function to build status labels
  Widget _buildStatusLabel(String text, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(
            color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
      ),
    );
  }

  // Helper function to build a card for each room
  Widget _buildRoomCard(String roomName, int roomID, String capacity,
      String wifi, String imagePath, List<Map<String, dynamic>> slots) {
    return GestureDetector(
      onTap: () {
        // Navigate to the booking page
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => StuBooking(
              role: 'student',
              roomID: roomID,
              accessToken: widget.accessToken,
            ),
          ),
        );
      },
      child: Container(
        width: MediaQuery.of(context).size.width - 32,
        height: 180, // Increased height for displaying the slots more clearly
        child: Stack(
          children: [
            Card(
              color: Color(0xFFECE6F0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Container(
                      width: 90,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        image: DecorationImage(
                          image: (imagePath.isNotEmpty)
                              ? AssetImage('assets/images/$imagePath')
                              : AssetImage('assets/images/room1.png')
                                  as ImageProvider,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            roomName,
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.person, size: 16),
                                  SizedBox(width: 4),
                                  Text('Capacity: $capacity'),
                                ],
                              ),
                              Row(
                                children: [
                                  Icon(
                                    wifi == '0'
                                        ? Icons.signal_wifi_off
                                        : Icons.wifi,
                                    size: 16,
                                  ),
                                  SizedBox(width: 4),
                                  Text('Wifi:  ${wifi == '0' ? "No" : "Free"}'),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          // Time slots under the wifi
                          Column(
                            children: _buildSlotGrid(slots),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Positioned forward arrow icon at the top-right corner
            Positioned(
              top: 8,
              right: 8,
              child: IconButton(
                icon: Icon(Icons.arrow_forward, color: Colors.black),
                onPressed: () {
                  // Handle the forward arrow action (e.g., navigate to next page)
                  GestureDetector;
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper function to build a grid of 4 slots (2x2 layout)
  List<Widget> _buildSlotGrid(List<Map<String, dynamic>> slots) {
    List<Widget> slotWidgets = [];
    int slotIndex = 0;

    // 2x2 grid layout: top-left, top-right, bottom-left, bottom-right
    for (int row = 0; row < 2; row++) {
      List<Widget> rowWidgets = [];
      for (int col = 0; col < 2; col++) {
        if (slotIndex < slots.length) {
          rowWidgets.add(
            Expanded(
              child: _buildSlotLabel(
                slots[slotIndex]['time'],
                _getSlotColor(slots[slotIndex]['status']),
              ),
            ),
          );
          slotIndex++;
        } else {
          rowWidgets.add(
            Expanded(
              child: Container(), // Empty slot if not enough slots
            ),
          );
        }
      }
      slotWidgets.add(
        Row(
          children: rowWidgets,
        ),
      );
    }

    return slotWidgets;
  }

  // Helper function to get the color based on the slot status
  Color _getSlotColor(RoomStatus status) {
    switch (status) {
      case RoomStatus.free:
        return Color(0xFF4DC591); // Green for Free
      case RoomStatus.reserved:
        return Color(0xFFFF0000); // Red for Reserved
      case RoomStatus.pending:
        return Color(0xFFFFB948); // Orange for Pending
      case RoomStatus.disabled:
        return Color(0xFF88889D); // Gray for Disabled
      default:
        return Color(0xFF4DC591); // Default to green if unknown
    }
  }

  // Helper function to build the slot label
  Widget _buildSlotLabel(String time, Color color) {
    return Container(
      margin: EdgeInsets.all(4),
      padding: EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(
          time,
          style: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
