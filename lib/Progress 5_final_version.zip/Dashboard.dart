import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:mobile_app_project/config.dart';
import 'package:http/http.dart' as http;

class DashboardScreen extends StatefulWidget {
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
  final String role;

  DashboardScreen({Key? key, required this.role}) : super(key: key);
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 3;

  // State variables for the data fetched from the API
  int totalRooms = 0;
  int totalSlots = 0;
  int freeSlots = 0;
  int pendingSlots = 0;
  int reservedSlots = 0;
  int disabledSlots = 0;
  bool isLoading = false;

  // Function to fetch data from the API
  Future<void> fetchData() async {
    final prefs = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('token');

    if (accessToken == null) {
      print('Access token is not available');
      MotionToast.error(
        title: Text("Error"),
        description: Text("Access token not available."),
      ).show(context);
      return;
    }

    try {
      final response = await http.get(
        Uri.parse(
            '${Config.baseUrl}/dashboard'), // Replace with your actual API endpoint
        headers: {'Authorization': 'Bearer $accessToken'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          totalRooms = data['totalRooms'];
          totalSlots = data['totalSlots'];
          freeSlots = data['freeSlots'];
          pendingSlots = data['pendingSlots'];
          reservedSlots = data['reservedSlots'];
          disabledSlots = data['disabledSlots'];
        });
        MotionToast.success(
          title: Text("Success"),
          description: Text("Dashboard data loaded successfully."),
        ).show(context);
      } else {
        final errorData = jsonDecode(response.body);
        MotionToast.warning(
          title: Text("Warning"),
          description:
              Text(errorData['message'] ?? "Failed to load dashboard data."),
        ).show(context);
      }
    } catch (error) {
      MotionToast.error(
        title: Text("Error"),
        description: Text("Error fetching dashboard data."),
      ).show(context);
      print('Error fetching dashboard data: $error');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'TOTAL',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: _buildTotalCard(
                              count: totalRooms.toString(),
                              label: 'Study Rooms',
                              icon: Icons.meeting_room,
                              backgroundColor: Colors.lightBlue.shade100,
                              iconColor: Colors.blue,
                            ),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: _buildTotalCard(
                              count: totalSlots.toString(),
                              label: 'Time Slots',
                              icon: Icons.calendar_today,
                              backgroundColor: Colors.deepPurple.shade100,
                              iconColor: Colors.purple,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      GridView.count(
                        crossAxisCount: 2,
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        children: [
                          _buildStatusCard(
                            count: freeSlots.toString(),
                            label: 'Free',
                            backgroundColor: Colors.lightGreen.shade100,
                            textColor: Color(0xFF4DC591),
                            icon: Icons.check_circle,
                          ),
                          _buildStatusCard(
                            count: pendingSlots.toString(),
                            label: 'Pending',
                            backgroundColor: Colors.orange.shade100,
                            textColor: Color(0xFFB87333),
                            icon: Icons.access_time,
                          ),
                          _buildStatusCard(
                            count: disabledSlots.toString(),
                            label: 'Disabled',
                            backgroundColor: Colors.grey.shade300,
                            textColor: Color(0xFF88889D),
                            icon: Icons.block,
                          ),
                          _buildStatusCard(
                            count: reservedSlots.toString(),
                            label: 'Reserved',
                            backgroundColor: Colors.red.shade100,
                            textColor: Color(0xFFFF0000),
                            icon: Icons.bookmark,
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: Container(
                          height: 200,
                          padding: EdgeInsets.all(16),
                          child: _buildPieChart(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildTotalCard({
    required String count,
    required String label,
    required IconData icon,
    required Color backgroundColor,
    required Color iconColor,
  }) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: iconColor,
            size: 23,
          ),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                count,
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard({
    required String count,
    required String label,
    required Color backgroundColor,
    required Color textColor,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: textColor,
            size: 23,
          ),
          SizedBox(height: 10),
          Text(
            count,
            style: TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(fontSize: 12, color: textColor),
          ),
        ],
      ),
    );
  }

  Widget _buildPieChart() {
    return PieChart(
      PieChartData(
        sections: [
          PieChartSectionData(
            value: freeSlots.toDouble(),
            color: Color(0xFF4DC591),
            title: 'Free',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: pendingSlots.toDouble(),
            color: Color(0xFFFFB948),
            title: 'Pending',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: disabledSlots.toDouble(),
            color: Color(0xFF88889D),
            title: 'Disabled',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: reservedSlots.toDouble(),
            color: Color(0xFFFF0000),
            title: 'Reserved',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
        sectionsSpace: 3,
        centerSpaceRadius: 40,
      ),
    );
  }
}
