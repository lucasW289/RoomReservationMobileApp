// config.dart
class Config {
  static const String baseUrl = 'http://172.16.22.165:5001';
}
