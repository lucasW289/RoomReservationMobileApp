import 'package:flutter/material.dart';

class BookingRequestsPage extends StatefulWidget {
  @override
  _BookingRequestsPageState createState() => _BookingRequestsPageState();
  final String role;

  // Constructor to accept role
  BookingRequestsPage({Key? key, required this.role}) : super(key: key);
}

class _BookingRequestsPageState extends State<BookingRequestsPage> {
  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    // Handle navigation to other pages if needed
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Pending Requests",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                hintText: 'Manage Booking Requests',
                prefixIcon: Icon(Icons.search,
                    color: const Color.fromARGB(255, 68, 68, 68)),
                suffixIcon:
                    Icon(Icons.close, color: Color.fromARGB(255, 68, 68, 68)),
                filled: true,
                fillColor: Color(0xFFECE6F0),
                contentPadding: EdgeInsets.symmetric(vertical: 12.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  BookingRequestCard(
                      room: "Room 1",
                      time: "08:00 - 10:00",
                      name: "Mr. Daniel",
                      id: "653200",
                      imageUrl: 'assets/images/room1.png'),
                  SizedBox(height: 16),
                  BookingRequestCard(
                      room: "Room 3",
                      time: "13:00 - 15:00",
                      name: "Mr. Duke",
                      id: "653206",
                      imageUrl: 'assets/images/room3.png'),
                  SizedBox(height: 16),
                  BookingRequestCard(
                      room: "Room 3",
                      time: "08:00 - 10:00",
                      name: "Ms. Angela",
                      id: "653201",
                      imageUrl: 'assets/images/room3.png'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BookingRequestCard extends StatelessWidget {
  final String room;
  final String time;
  final String name;
  final String id;
  final String imageUrl;

  BookingRequestCard({
    required this.room,
    required this.time,
    required this.name,
    required this.id,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: const Color.fromRGBO(236, 230, 240, 1),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    imageUrl,
                    width: 100, // Adjusted width to fit the layout
                    height: 100, // Adjusted height for a balanced look
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        room,
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 4),
                      Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFFFFB948),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          time,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text("$name\nID: $id", style: TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFFFF0000),
                      foregroundColor: Colors.white,
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    child: Text("Reject"),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF4DC591),
                      foregroundColor: Colors.white,
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    child: Text("Approve"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
