import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Your App Title',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false, // Hides the debug banner
      home: LectHistory(
          role:
              'approver'), // Set the initial screen to LectHistory or any other screen
    );
  }
}

enum RoomApprovalStatus { approved, rejected }

class LectHistory extends StatefulWidget {
  final String role; // Declare role parameter

  // Constructor to accept role
  LectHistory({Key? key, required this.role}) : super(key: key);

  @override
  _LectHistoryState createState() => _LectHistoryState();
}

class _LectHistoryState extends State<LectHistory> {
  int _selectedIndex = 2; // Set this to match the LectHistory index
  DateTime? _selectedDate; // Store the selected date

  // Example data for bookings
  List<Map<String, dynamic>> bookings = [
    {
      'roomName': 'Room 1',
      'capacity': '8 People',
      'wifi': 'Free Wifi',
      'status': RoomApprovalStatus.approved,
      'studentName': 'John Doe',
      'bookingDate': '2024-10-23', // Changed to ISO format for easy comparison
      'bookingTime': '08:00 - 10:00',
    },
    {
      'roomName': 'Room 2',
      'capacity': '10 People',
      'wifi': 'Free Wifi',
      'status': RoomApprovalStatus.rejected,
      'studentName': 'Jane Smith',
      'bookingDate': '2024-10-25', // Changed to ISO format for easy comparison
      'bookingTime': '13:00 - 15:00',
    },
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Color _getApprovalColor(RoomApprovalStatus status) {
    return status == RoomApprovalStatus.approved
        ? Color(0xFF4DC591)
        : Colors.red;
  }

  void _clearFilter() {
    setState(() {
      _selectedDate = null; // Clear the selected date
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // Use the custom header here
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'History',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Filter by Date',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101),
                        );
                        if (pickedDate != null) {
                          setState(() {
                            _selectedDate = pickedDate; // Store selected date
                          });
                        }
                      },
                      child: Text('Select Date'),
                    ),
                    SizedBox(width: 10),
                    if (_selectedDate != null)
                      GestureDetector(
                        onTap: _clearFilter,
                        child: Icon(
                          Icons.cancel,
                          color: Colors.red, // Icon color
                          size: 30, // Icon size
                        ),
                      ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: bookings
                    .where((booking) =>
                        _selectedDate == null ||
                        DateFormat('yyyy-MM-dd')
                            .parse(booking['bookingDate'])
                            .isAtSameMomentAs(_selectedDate!)) // Filter logic
                    .map((booking) => _buildRoomCard(
                          booking['roomName'],
                          booking['capacity'],
                          booking['wifi'],
                          booking['status'],
                          booking['studentName'],
                          booking['bookingDate'],
                          booking['bookingTime'],
                        ))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoomCard(
      String roomName,
      String capacity,
      String wifi,
      RoomApprovalStatus status,
      String studentName,
      String bookingDate,
      String bookingTime) {
    String imageName = roomName.toLowerCase().replaceAll(' ', '');

    return Container(
      width: 300,
      height: 160,
      child: Card(
        color: Color(0xFFECE6F0),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Container(
                width: 90,
                height: 140,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[200],
                  image: DecorationImage(
                    image: AssetImage('assets/images/$imageName.png'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(roomName,
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.people, size: 12, color: Colors.grey),
                        SizedBox(width: 4),
                        Text(capacity,
                            style: TextStyle(color: Colors.grey, fontSize: 10)),
                        SizedBox(width: 12),
                        Icon(Icons.wifi, size: 12, color: Colors.grey),
                        SizedBox(width: 4),
                        Text(wifi,
                            style: TextStyle(color: Colors.grey, fontSize: 10)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Booked by:',
                                style: TextStyle(
                                    fontSize: 10, fontWeight: FontWeight.bold)),
                            SizedBox(height: 4),
                            Text(studentName,
                                style: TextStyle(
                                    fontSize: 10, color: Colors.grey)),
                          ],
                        ),
                        Container(
                          height: 40, // Adjust this height to fit your needs
                          width: 80, // You can adjust width as needed
                          decoration: BoxDecoration(
                            color: _getApprovalColor(status),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Center(
                            child: Text(
                              status == RoomApprovalStatus.approved
                                  ? 'Approved'
                                  : 'Rejected',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Booking Date',
                            style: TextStyle(
                                fontSize: 10, fontWeight: FontWeight.bold)),
                        Text(bookingDate,
                            style: TextStyle(fontSize: 10, color: Colors.grey)),
                      ],
                    ),
                    SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Booking Time',
                            style: TextStyle(
                                fontSize: 10, fontWeight: FontWeight.bold)),
                        Text(bookingTime,
                            style: TextStyle(fontSize: 10, color: Colors.grey)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
