// config.dart
class Config {
  static const String baseUrl = 'http://172.25.80.1:5001';
}
