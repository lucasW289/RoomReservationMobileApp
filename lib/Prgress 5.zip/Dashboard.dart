import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class DashboardScreen extends StatefulWidget {
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
  final String role; // Declare role parameter

  // Constructor to accept role
  DashboardScreen({Key? key, required this.role}) : super(key: key);
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 3;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TOTAL',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _buildTotalCard(
                        count: '5',
                        label: 'Study Rooms',
                        icon: Icons.meeting_room,
                        backgroundColor: Colors.lightBlue.shade100,
                        iconColor: Colors.blue,
                      ),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: _buildTotalCard(
                        count: '20',
                        label: 'Time Slots',
                        icon: Icons.calendar_today,
                        backgroundColor: Colors.deepPurple.shade100,
                        iconColor: Colors.purple,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    _buildStatusCard(
                      count: '10',
                      label: 'Free',
                      backgroundColor: Colors.lightGreen.shade100,
                      textColor: Color(0xFF4DC591),
                      icon: Icons.check_circle,
                    ),
                    _buildStatusCard(
                      count: '6',
                      label: 'Pending',
                      backgroundColor: Colors.orange.shade100,
                      textColor: Color(0xFFB87333),
                      icon: Icons.access_time,
                    ),
                    _buildStatusCard(
                      count: '4',
                      label: 'Disabled',
                      backgroundColor: Colors.grey.shade300,
                      textColor: Color(0xFF88889D),
                      icon: Icons.block,
                    ),
                    _buildStatusCard(
                      count: '2',
                      label: 'Reserved',
                      backgroundColor: Colors.red.shade100,
                      textColor: Color(0xFFFF0000),
                      icon: Icons.bookmark,
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Center(
                  child: Container(
                    height: 200,
                    padding: EdgeInsets.all(16),
                    child: _buildPieChart(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTotalCard({
    required String count,
    required String label,
    required IconData icon,
    required Color backgroundColor,
    required Color iconColor,
  }) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: iconColor,
            size: 28,
          ),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                count,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard({
    required String count,
    required String label,
    required Color backgroundColor,
    required Color textColor,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: textColor,
            size: 28,
          ),
          SizedBox(height: 10),
          Text(
            count,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(fontSize: 14, color: textColor),
          ),
        ],
      ),
    );
  }

  Widget _buildPieChart() {
    return PieChart(
      PieChartData(
        sections: [
          PieChartSectionData(
            value: 10,
            color: Color(0xFF4DC591),
            title: 'Free',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: 6,
            color: Color(0xFFFFB948),
            title: 'Pending',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: 4,
            color: Color(0xFF88889D),
            title: 'Disabled',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          PieChartSectionData(
            value: 2,
            color: Color(0xFFFF0000),
            title: 'Reserved',
            radius: 70,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
        sectionsSpace: 3,
        centerSpaceRadius: 40,
      ),
    );
  }
}
